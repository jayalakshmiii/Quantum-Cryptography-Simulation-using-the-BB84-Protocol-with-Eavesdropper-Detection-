# bb84_qkd.py
# Cleaned and commented BB84 demonstration code (illustrative).
# Requires Qiskit and Qiskit Aer to run; this file is intended as a reference implementation.

import random
from qiskit import QuantumCircuit
from qiskit_aer import Aer

def random_bits(n):
    return [random.randint(0,1) for _ in range(n)]

def random_bases(n):
    return [random.randint(0,1) for _ in range(n)]  # 0=Z, 1=X

def encode_qubits(bits, bases):
    circuits = []
    for bit, basis in zip(bits, bases):
        qc = QuantumCircuit(1,1)
        if basis == 0:  # Z basis
            if bit == 1:
                qc.x(0)
        else:  # X basis
            if bit == 1:
                qc.x(0)
            qc.h(0)
        circuits.append(qc)
    return circuits

def measure_qubits(circuits, measurement_bases):
    backend = Aer.get_backend('qasm_simulator')
    results = []
    for qc, mb in zip(circuits, measurement_bases):
        new_qc = qc.copy()
        if mb == 1:
            new_qc.h(0)  # rotate to X basis before measuring
        new_qc.measure(0,0)
        job = backend.run(new_qc, shots=1, memory=True)
        result = job.result()
        bit = int(result.get_memory()[0])
        results.append(bit)
    return results

def sift_keys(a_bases, b_bases, a_bits, b_bits):
    key_a = [bit for bit, ab, bb in zip(a_bits, a_bases, b_bases) if ab == bb]
    key_b = [bit for bit, ab, bb in zip(b_bits, a_bases, b_bases) if ab == bb]
    return key_a, key_b

if __name__ == '__main__':
    n = 20
    alice_bits = random_bits(n)
    alice_bases = random_bases(n)
    bob_bases = random_bases(n)

    print('Alice bits:   ', alice_bits)
    print('Alice bases:  ', alice_bases)
    print('Bob bases:    ', bob_bases)

    qubits = encode_qubits(alice_bits, alice_bases)
    bob_results = measure_qubits(qubits, bob_bases)

    alice_key, bob_key = sift_keys(alice_bases, bob_bases, alice_bits, bob_results)
    print('Alice sifted key:', alice_key)
    print('Bob sifted key:  ', bob_key)

    errors = sum(1 for a,b in zip(alice_key, bob_key) if a != b)
    error_rate = (errors / len(alice_key))*100 if alice_key else 0
    print(f'Error rate: {error_rate:.2f}%')
    if error_rate > 20:
        print('Possible eavesdropper detected!')
    else:
        print('Key looks secure (demo threshold).')
